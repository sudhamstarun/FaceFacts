const nodeCouchDb = require('node-couchdb');

const couch = new nodeCouchDb({
	host: '54.255.235.92',
	port: 5984,
	auth: {
		user: 'admin',
		pass: 'admin'
	}
})

module.exports = {
	getFirms: function() {
		return couch.get('facefacts', '_design/firm/_view/firm', {});
	},
	createFirm: function(id, firmName) {
		return couch.insert("facefacts", {
			_id: id,
			type: "firm",
			firmName: firmName,
			firmCode: id.substring(26, 32)
		})
	},
	getUsers: function() {
		return couch.get('facefacts', '_design/user/_view/user', {});
	},
	createUser: function(id, firmName, username, password) {
		return couch.insert("facefacts", {
			_id: id,
			type: "user",
			firmName: firmName,
			username: username,
			password: password
		})
	},
	getEmployees: function() {
		return couch.get('facefacts', '_design/firm/_view/employee', {});
	}
}