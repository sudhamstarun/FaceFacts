const express = require('express');
const app = express();
const bodyParser = require('body-parser')
const path = require('path');

//routes
const user = require("./routes/user")

app.use(bodyParser.json());

app.use(function (req, res, next) {
    res.setHeader('Access-Control-Allow-Headers', 'accept, authorization, content-type, x-requested-with');
    res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE');
    res.setHeader('Access-Control-Allow-Origin', '*');
    next();
});

app.get('/ping', function (req, res) {
	console.log(req.body);
	res.header("Access-Control-Allow-Origin", "*");
	res.status(200).send({
		response: "working"
	});
})

app.get('/frontend', function (req, res){
	res.header("Access-Control-Allow-Origin", "*");
	res.sendFile(path.join(__dirname + '/frontend/home.html'));
});

app.post('/videoData', function (req, res) {
	res.header("Access-Control-Allow-Origin", "*");
	res.header('Content-Type', 'application/json');
	// NOTE: need to set content type to application/json
	var videoIndex = req.body.videoIndex;

	res.sendFile(path.join(__dirname + '/json/' + videoIndex + '.json'));
});

app.use('/user', user);

var server = app.listen(4321, function () {

  var host = server.address().address
  var port = server.address().port

  console.log("Listening at http://%s:%s", host, port)

})