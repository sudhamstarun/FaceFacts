const express = require("express");
var router = express.Router();

const unirest = require('unirest');

const db = require("../services/db")

router.get("/:firmName/employee", function(req, res){
	// var targetFirmName = req.param.firmName;

	// db.getFirms().then(
	// 	function (data) {
	// 		for (var i = 0; i < data.data.rows.length; i++) {
	// 			if (data.data.rows[i].key.firmName == targetFirmName) {
	// 				db.getEmployees().then(
	// 					function (data) {
	// 						var employees = [];
	// 						for (var j = 0; j < data.data.rows.length; j++) {
	// 							if (data.data.rows[j].key.firmName == targetFirmName) {
	// 								employees.append(data.data.rows[j]);
	// 							}
	// 						}
	// 						res.status(200).send({
	// 							status: "success",
	// 							employees: employees
	// 						})
	// 					}, function (err) {
	// 						res.status(500).send({
	// 							status: "error",
	// 							err: "DB server error"
	// 						})
	// 					}
	// 				);
	// 				i = data.data.rows.length;
	// 			} else {
	// 				if (i == data.data.rows.length-1) {
	// 					res.status(400).send({
	// 						status: "error",
	// 						err: "Invalid firm name"
	// 					})
	// 				}
	// 			}
	// 		}
	// 		if (data.data.rows.length === 0) {
	// 			res.status(400).send({
	// 				status: "error",
	// 				err: "Invalid firm name"
	// 			})
	// 		}
	// 	}, function (err) {
	// 		res.status(500).send({
	// 			status: "error",
	// 			err: "DB server error"
	// 		})
	// 	}
	// );

})

router.post("/:firmName/employee", function(req, res){
	var firmName = req.param.firmName;
})

module.exports = router;