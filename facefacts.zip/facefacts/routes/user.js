const express = require("express");
var router = express.Router();

const unirest = require('unirest');

const db = require("../services/db")

router.post("/login", function(req, res){
	var targetFirmName = req.body.firmName;
	var username = req.body.username;
	var password = req.body.password;

	db.getFirms().then(
		function (data) {
			for (var i = 0; i < data.data.rows.length; i++) {
				if (data.data.rows[i].key.firmName == targetFirmName) {
					db.getUsers().then(
						function (data) {
							for (var i = 0; i < data.data.rows.length; i++) {
								if (data.data.rows[i].key.username == username && data.data.rows[i].key.firmName == targetFirmName) {
									if (data.data.rows[i].key.password == password) {
										res.header("Access-Control-Allow-Origin", "*");
										res.status(200).send({
											status: "authenticated"
										})
									} else {
										res.header("Access-Control-Allow-Origin", "*");
										res.status(400).send({
											status: "error",
											err: "Invalid password"
										})
									}
									i = data.data.rows.length;
								} else {
									if (i == data.data.rows.length-1) {
										res.header("Access-Control-Allow-Origin", "*");
										res.status(400).send({
											status: "error",
											err: "Invalid username2"
										})
									}
								}
							}
							if (data.data.rows.length === 0) {
								res.header("Access-Control-Allow-Origin", "*");
								res.status(400).send({
									status: "error",
									err: "Invalid username1"
								})
							}
						}, function (err) {
							res.header("Access-Control-Allow-Origin", "*");
							res.status(500).send({
								status: "error",
								err: "DB server error"
							})
						}
					);
					i = data.data.rows.length;
				} else {
					if (i == data.data.rows.length-1) {
						res.header("Access-Control-Allow-Origin", "*");
						res.status(400).send({
							status: "error",
							err: "Invalid firm name1"
						})
					}
				}
			}
			if (data.data.rows.length === 0) {
				res.header("Access-Control-Allow-Origin", "*");
				res.status(400).send({
					status: "error",
					err: "Invalid firm name2"
				})
			}
		}, function (err) {
			res.header("Access-Control-Allow-Origin", "*");
			res.status(500).send({
				status: "error",
				err: "DB server error"
			})
		}
	);
})

router.post("/register", function(req, res){
	var targetFirmName = req.body.firmName;
	var targetFirmCode = req.body.firmCode;
	var username = req.body.username;
	var password = req.body.password;

	if (targetFirmCode == null) {
		db.getFirms().then(
			function (data) {
				for (var i = 0; i < data.data.rows.length; i++) {
					if (data.data.rows[i].key.firmName == targetFirmName) {
						res.header("Access-Control-Allow-Origin", "*");
						res.status(400).send({
							status: "error",
							err: "Firm name is being used already"
						})
						i = data.data.rows.length;
					} else {
						if (i == data.data.rows.length-1) {
							unirest.get('http://54.255.235.92:5984/_uuids?count=2').headers({'Accept':'application/json'}).end(function(response){
								db.createFirm(response.body.uuids[0], targetFirmName).then(
									function (data) {
										db.createUser(response.body.uuids[1], targetFirmName, username, password).then(
											function (data) {
												res.header("Access-Control-Allow-Origin", "*");
												res.status(200).send({
													status: "success"
												});
											}, function (err) {
												res.header("Access-Control-Allow-Origin", "*");
												res.status(500).send({
													status: "error",
													err: "DB server error"
												})
											}
										);
									}, function (err) {
										res.header("Access-Control-Allow-Origin", "*");
										res.status(500).send({
											status: "error",
											err: "DB server error"
										})
									}
								);
							});
						}
					}
				}
				if (data.data.rows.length === 0) {
					db.createFirm(targetFirmName).then(
						function (data) {
							unirest.get('http://54.255.235.92:5984/_uuids?count=2').headers({'Accept':'application/json'}).end(function(response){
								db.createFirm(response.body.uuids[0], targetFirmName).then(
									function (data) {
										db.createUser(response.body.uuids[1], targetFirmName, username, password).then(
											function (data) {
												res.header("Access-Control-Allow-Origin", "*");
												res.status(200).send({
													status: "success"
												});
											}, function (err) {
												res.header("Access-Control-Allow-Origin", "*");
												res.status(500).send({
													status: "error",
													err: "DB server error"
												})
											}
										);
									}, function (err) {
										res.header("Access-Control-Allow-Origin", "*");
										res.status(500).send({
											status: "error",
											err: "DB server error"
										})
									}
								);
							});
						}, function (err) {
							res.header("Access-Control-Allow-Origin", "*");
							res.status(500).send({
								status: "error",
								err: "DB server error"
							})
						}
					);
				}
			}, function (err) {
				res.header("Access-Control-Allow-Origin", "*");
				res.status(500).send({
					status: "error",
					err: "DB server error"
				})
			}
		);
	} else {
		db.getFirms().then(
			function (data) {
				for (var i = 0; i < data.data.rows.length; i++) {
					if (data.data.rows[i].key.firmName == targetFirmName) {
						if (data.data.rows[i].key.firmCode == targetFirmCode) {
							db.getUsers().then(
								function (data) {
									for (var i = 0; i < data.data.rows.length; i++) {
										if (data.data.rows[i].key.username == username && data.data.rows[i].key.firmName == targetFirmName) {
											res.header("Access-Control-Allow-Origin", "*");
											res.status(400).send({
												status: "error",
												err: "Username is already used"
											})
											i = data.data.rows.length;
										} else {
											if (i == data.data.rows.length-1) {
												unirest.get('http://54.255.235.92:5984/_uuids?count=1').headers({'Accept':'application/json'}).end(function(response){
													db.createUser(response.body.uuids[0], targetFirmName, username, password).then(
														function (data) {
															res.header("Access-Control-Allow-Origin", "*");
															res.status(200).send({
																status: "success"
															});
														}, function (err) {
															res.header("Access-Control-Allow-Origin", "*");
															res.status(500).send({
																status: "error",
																err: "DB server error"
															})
														}
													);
												});
											}
										}
									}
									if (data.data.rows.length === 0) {
										unirest.get('http://54.255.235.92:5984/_uuids?count=1').headers({'Accept':'application/json'}).end(function(response){
											db.createUser(response.body.uuids[0], targetFirmName, username, password).then(
												function (data) {
													res.header("Access-Control-Allow-Origin", "*");
													res.status(200).send({
														status: "success"
													});
												}, function (err) {
													res.header("Access-Control-Allow-Origin", "*");
													res.status(500).send({
														status: "error",
														err: "DB server error"
													})
												}
											);
										});
									}
								}, function (err) {
									res.header("Access-Control-Allow-Origin", "*");
									res.status(500).send({
										status: "error",
										err: "DB server error"
									})
								}
							);	
						} else {
							res.header("Access-Control-Allow-Origin", "*");
							res.status(400).send({
								status: "error",
								err: "Invalid firm code"
							})
						}
						i = data.data.rows.length;
					} else {
						if (i == data.data.rows.length-1) {
							res.header("Access-Control-Allow-Origin", "*");
							res.status(400).send({
								status: "error",
								err: "Invalid firm name"
							})
						}
					}
				}
				if (data.data.rows.length === 0) {
					if (i == data.data.rows.length-1) {
						res.header("Access-Control-Allow-Origin", "*");
						res.status(400).send({
							status: "error",
							err: "Invalid firm name"
						})
					}
				}
			}, function (err) {
				res.header("Access-Control-Allow-Origin", "*");
				res.status(500).send({
					status: "error",
					err: "DB server error"
				})
			}
		);
	}
})

module.exports = router;