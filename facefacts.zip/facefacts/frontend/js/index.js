$('input[type="submit"]').mousedown(function(){
	$(this).css('background', '#2ecc71');
});
$('input[type="submit"]').mouseup(function(){
	$(this).css('background', '#1abc9c');
});

$('#loginform').click(function(){
	$('.register').hide();
	$('#registerform').removeClass('green');
	$('.login').fadeToggle('slow');
	$(this).toggleClass('green');
});

$('#registerform').click(function(){
	$('.login').hide();
	$('#loginform').removeClass('green');
	
	$('#regfirm').click(function(){
	$('.firmform').hide();
	$('.userform').show();
	});
	$('.firmform').show();
	$('.userform').hide();
	
	$('.register').fadeToggle('slow');
	$(this).toggleClass('green');
});

window.onload = function(){
	$('.login').fadeToggle('slow');
	$('#loginform').toggleClass('green');
}
 